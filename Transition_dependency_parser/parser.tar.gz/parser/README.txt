a) Programming language used: python version 3

b) To compile and run my program, please use the following command:

        python3 parser.py -simulate <file.txt>

        python3 parser.py -genops <operators.txt> <file.txt>

c) I tested my program on cade machine and it worked.

d) No known bugs or limitations it works perfectly for all the given files.
